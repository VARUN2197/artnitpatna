from django.contrib import admin
from gallery.models import Post

admin.site.register(Post)

