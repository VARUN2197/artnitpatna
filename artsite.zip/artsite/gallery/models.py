from django.db import models

class Post(models.Model):
    title = models.CharField(max_length=120)
    content = models.TextField(null=True)
    image = models.FileField(null = True)
    date = models.DateTimeField()

    def __str__(self):
        return self.title
