
from django.conf.urls import url,include
from django.contrib import admin

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^', include('homepage.urls')),
    url(r'^gallery.html', include('gallery.urls')),
    url(r'^aboutus.html', include('aboutus.urls')),
]
